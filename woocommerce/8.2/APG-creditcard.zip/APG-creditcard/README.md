# Wordpress + Woocommerce payment gateway plugin

- wordpress 6.4+
- woocommerce 8.2

# Usage

compress APG-credicard folder to APG-creditcard.zip

upload zip file in your wordpress dashboard plugin menu

then setting in Woocommerce->Settings->Payments, enable it and config your merchant account, secure code, etc.

![img](tutorial-img.png)

